# Proyecto Happy Art - Tienda Online

## Base de datos productos

![alt text](image-1.png)

## Base de datos usuarios

![alt text](image-2.png)